# Custom properties provider Extension

Add description ...


...


...


Add this dependency to your application pom.xml

```
<groupId>com.my.company.custom.provider</groupId>
<artifactId>mule-custom-properties-providers-module</artifactId>
<version>1.0.0-SNAPSHOT</version>
```
