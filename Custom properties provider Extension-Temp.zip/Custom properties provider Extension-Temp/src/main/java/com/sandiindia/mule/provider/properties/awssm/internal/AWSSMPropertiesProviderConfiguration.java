package com.sandiindia.mule.provider.properties.awssm.internal;


import org.mule.runtime.extension.api.annotation.param.Parameter;

/**
 * This class represents an extension configuration, values set in this class are commonly used across multiple
 * operations since they represent something core from the extension.
 */
public class AWSSMPropertiesProviderConfiguration {


  @Parameter
  private String region;

  
  //@Parameter
  //private String authType;
  
  @Parameter
  private String accessKey;
  
  @Parameter
  private String secretKey;
  
  

  public String getRegion() {
	  return region;
  }
  
  
  //public String getAuthType() {
  //  return authType;
  //}
  
  
  
  public String getAccessKey()
  {
	  return  accessKey;
  }

  
  public String getSecretKey()
  {
	  return secretKey;
  }
  
  

}