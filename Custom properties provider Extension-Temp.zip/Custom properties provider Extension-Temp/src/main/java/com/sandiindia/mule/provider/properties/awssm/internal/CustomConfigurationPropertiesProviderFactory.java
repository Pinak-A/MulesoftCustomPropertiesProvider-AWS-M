package com.sandiindia.mule.provider.properties.awssm.internal;


import static com.sandiindia.mule.provider.properties.awssm.internal.AWSSMPropertiesProviderExtension.AWSSM_PROPERTIES_PROVIDER;
//import com.sandiindia.mule.provider.properties.awssm.internal.*;

import java.io.StringReader;
import java.util.Optional;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;

import org.mule.runtime.api.component.ComponentIdentifier;
import org.mule.runtime.config.api.dsl.model.ConfigurationParameters;
import org.mule.runtime.config.api.dsl.model.ResourceProvider;
import org.mule.runtime.config.api.dsl.model.properties.ConfigurationPropertiesProvider;
import org.mule.runtime.config.api.dsl.model.properties.ConfigurationPropertiesProviderFactory;
import org.mule.runtime.config.api.dsl.model.properties.ConfigurationProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
//import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.http.nio.netty.NettyNioAsyncHttpClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerAsyncClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueResponse;
import software.amazon.awssdk.services.secretsmanager.model.SecretsManagerException;

/**
 * Builds the provider for a custom-properties-provider:config element.
 *
 * @since 1.0
 */
public class CustomConfigurationPropertiesProviderFactory implements ConfigurationPropertiesProviderFactory {

	public static final String EXTENSION_NAMESPACE = "aws-sm-properties-provider";
	private static final Logger LOGGER = LoggerFactory.getLogger(CustomConfigurationPropertiesProviderFactory.class);
	private final static String CUSTOM_PROPERTIES_PREFIX = "aws-sm-getSecretValue::";

	 private static AwsCredentialsProvider getCredentialsV2(String AccessKey,String SecretKey) throws Exception {
		 

		    
		    
		    
	        return StaticCredentialsProvider.create(AwsBasicCredentials.create(AccessKey,SecretKey));
	    }
	
	
	
	
	@Override
	public ComponentIdentifier getSupportedComponentIdentifier() {
		return AWSSM_PROPERTIES_PROVIDER;
	}

	/*
	 * private AwsCredentialsProvider getSDKCredProvider(String credType) { return
	 * ProfileCredentialsProvider.create(); }
	 */

	public String getAWSSecretValue(String region, String secretName, String key ,String AccessKey,String SecretKey) {

		Region REG = Region.of(region);
	 
	    		
	    		
	    
		SecretsManagerAsyncClient secretsClient=null;
		try {
			secretsClient = SecretsManagerAsyncClient.builder().region(REG)
					.httpClient(NettyNioAsyncHttpClient.builder().build()).credentialsProvider(getCredentialsV2(AccessKey,SecretKey))
					.build();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			LOGGER.debug("Looking for secret " + secretName + " **** Key ***** " + key);
			GetSecretValueRequest valueRequest = GetSecretValueRequest.builder().secretId(secretName).build();

			GetSecretValueResponse valueResponse;
			try {
				valueResponse = secretsClient.getSecretValue(valueRequest).get();
				
				String secretData = valueResponse.secretString();
				
				JsonReader jsonReader = Json.createReader(new StringReader(secretData));
				
				JsonObject secretObject = jsonReader.readObject();
				
				String secret = secretObject.getString(key);
				
				return secret;
			} catch (Exception e) {
				LOGGER.error("****Error while loading secret*****", e);
			}

			return null;

		} catch (SecretsManagerException e) {
			LOGGER.error("Error while loading secret", e);
			return null;
		}
	}

	@Override
	public ConfigurationPropertiesProvider createProvider(ConfigurationParameters parameters,
			ResourceProvider externalResourceProvider) {

		// This is how you can access the configuration parameter of the
		// <custom-properties-provider:config> element.				
      String accessKeyValue = parameters.getStringParameter("accessKey");
     String secretKeyValue = parameters.getStringParameter("secretKey");

	   
		
		
		
		LOGGER.info("**********Creating AWS Secret Manager Properties Provider*********");
		String awsRegion = parameters.getStringParameter("region");
	//	String authType = parameters.getStringParameter("authType");
		LOGGER.debug("Region" + awsRegion);
	//	LOGGER.debug("Auth Type" + authType);

		return new ConfigurationPropertiesProvider() {

			
			
			
			@Override
			public Optional<ConfigurationProperty> getConfigurationProperty(String configurationAttributeKey) {
				if (configurationAttributeKey.startsWith(CUSTOM_PROPERTIES_PREFIX)) {
					String effectiveKey = configurationAttributeKey.substring(CUSTOM_PROPERTIES_PREFIX.length());
					String[] secretParts = effectiveKey.split(":");
					
					String propertyValue = getAWSSecretValue(awsRegion, secretParts[0], secretParts[1], accessKeyValue, secretKeyValue);
					if (effectiveKey != null) {
						return Optional.of(new ConfigurationProperty() {

							@Override
							public Object getSource() {
								return "custom provider source";
							}

							@Override
							public Object getRawValue() {
								return propertyValue;
							}

							@Override
							public String getKey() {
								return effectiveKey;
							}
						});
					}
				}
				return Optional.empty();
			}
			
			
		
			
			
			
			
			
			
			
			
			
			
			
			

			@Override
			public String getDescription() {
				// TODO change to a meaningful name for error reporting.
				return "AWS Secret Manager Properties Provider";
			}
		};
	}

}